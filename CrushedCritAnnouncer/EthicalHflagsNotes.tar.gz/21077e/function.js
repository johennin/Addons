// vi: ft=javascript.jinja2

// flag{d8d9da451faff951fd36763f373fccd620dbafb7b016cf},

'use strict';
const defaultResponse = 'Hello, I am a cloud function.';
const MAX_CHARS = 15;

/**
 * Sends the default response of the function and exits.
 *
 * @param {!express:Response} res HTTP response context.
 * @param appResponse An object representing the HTTP response contents.
 */
const sendDefaultResponse = function (res, msg) {
      console.log("Sending default");
      msg.message = defaultResponse;
      res.status(200).send(msg);

};

/**
 * Checks if user-provided messages contain forbidden characters.
 * Messages must be alphanumeric, may contain full stops (.),
 * and be less than 16 characters.
 *
 * @param msg A text string fetched from the HTTP request.
 * @return Boolean False if illegal characters or length were encountered.
 */
const checkMessage = function (msg) {
      console.log("Checking message...");
      var pattern = /^[a-zA-Z0-9\.]+$/i;
      if(msg && msg.length <= MAX_CHARS && msg.length > 0 && pattern.exec(msg)){
            console.log("Message passed")
            return true;
      }
      console.log("Message blocked");
      return false;
};

/**
 * Responds to any HTTP request.
 *
 * @param {!express:Request} req HTTP request context.
 * @param {!express:Response} res HTTP response context.
 */
exports.iDareYouToHackMe = (req, res) => {
      let debugPassword = "f6Bpn0m9WG" //Change me

      let appResponse = {
            "from": "Ethical Hacking Function"
      };

      try {
            console.log(req.query);
            console.log(req.body);
            console.log(req.get('content-type'));
            console.log(req.method);

            switch(req.method){
                  case 'GET':
                        console.log("GET request");
                        if(!checkMessage(req.query.message)){
                              throw{
                                    name: "IllegalMessageError",
                                    message: "[GET] Undefined or illegal message received."
                              };
                        }

                        appResponse.message = req.query.message;

                        console.log("Send this: " + appResponse.message);
                        console.log(appResponse);
                        res.status(200).send(appResponse);
                        break;

                  case 'POST':
                        console.log("POST request");
                        switch(req.get('content-type')){
                              case 'application/json':
                                    console.log("application/json");

                                    if(!checkMessage(req.body.message)){
                                          throw{
                                                name: "IllegalMessageError",
                                                message: "[POST] Undefined or illegal message received."
                                          };
                                    }

                                    appResponse.message = req.body.message;

                                    console.log("Send this: " + appResponse.message);
                                    console.log(appResponse);
                                    res.status(200).send(appResponse);
                                    break;
                        default:
                              sendDefaultResponse(res, appResponse);

                        }// Content type switch

                        break;
                  default:
                        sendDefaultResponse(res, appResponse);
                        break;

            }// HTTP method switch

      } catch (e) {
            console.log("Error: " + e.message);
            sendDefaultResponse(res, appResponse);
      }
};
